package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class APActivity extends AppCompatActivity {


    private SQLiteDatabase bancoDados;
    EditText idcomida, mesa, status, observação;
    public Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apactivity);

        idcomida = (EditText) findViewById(R.id.idcomida);
        mesa = (EditText) findViewById(R.id.numero);
        status = (EditText) findViewById(R.id.status);
        observação = (EditText) findViewById(R.id.observação);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);
        carregarDados(id);
    }

    public void carregarDados(int id)
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM pedido WHERE id = " + id ,null);

            if(cursor.moveToNext()) {
                idcomida.setText((Integer.toString(cursor.getInt(1))));
                mesa.setText((Integer.toString(cursor.getInt(2))));
                status.setText(cursor.getString(3));
                observação.setText(cursor.getString(4));

            }
            bancoDados.close();

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void alterar(View view){
        int valueValor= Integer.parseInt(idcomida.getText().toString());
        int valueValor1= Integer.parseInt(mesa.getText().toString());
        String valueNome = status.getText().toString();
        String valueNome1 = observação.getText().toString();

        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            String sql = "UPDATE pedido SET idcomida = ?, mesa = ?, status = ?, observação = ? WHERE id = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);

            stmt.bindLong(1, valueValor);
            stmt.bindLong(2, valueValor1);
            stmt.bindString(3,valueNome);
            stmt.bindString(4, valueNome1);
            stmt.bindLong(5, id);

            stmt.executeUpdateDelete();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }

        finish();
    }
}
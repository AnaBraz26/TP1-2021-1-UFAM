package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ACActivity extends AppCompatActivity {


    private SQLiteDatabase bancoDados;
    public EditText nomecomida, ingredientes, valor;
    public Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acactivity);

        nomecomida = (EditText) findViewById(R.id.nomecomida);
        ingredientes = (EditText) findViewById(R.id.ingredientes);
        valor = (EditText) findViewById(R.id.valor);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);
        carregarDados(id);
    }

    public void carregarDados(int id)
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM cardapio WHERE id = " + id ,null);

            if(cursor.moveToNext()) {
                nomecomida.setText(cursor.getString(1));
                ingredientes.setText(cursor.getString(2));
                valor.setText((Double.toString(cursor.getDouble(3))));
            }
            bancoDados.close();

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void alterar(View view){
        String valueNome = nomecomida.getText().toString();
        String valueNome1 = ingredientes.getText().toString();
        double valueValor= Double.parseDouble(valor.getText().toString());
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            String sql = "UPDATE cardapio SET nomecomida = ?, ingredientes = ?, valor = ? WHERE id = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,valueNome);
            stmt.bindString(2,valueNome1);
            stmt.bindDouble(3, valueValor);
            stmt.bindLong(4,id);
            stmt.executeUpdateDelete();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        finish();
    }
}
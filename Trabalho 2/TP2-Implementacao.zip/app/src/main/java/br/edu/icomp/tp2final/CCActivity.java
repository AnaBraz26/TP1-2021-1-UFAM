package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class CCActivity extends AppCompatActivity {

    EditText nomecomida, ingredientes, valor;
    SQLiteDatabase bancoDados;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ccactivity);

        nomecomida = (EditText) findViewById(R.id.nomecomida);
        ingredientes = (EditText) findViewById(R.id.ingredientes);
        valor = (EditText) findViewById(R.id.valor);
    }

    public void cadastrar(View view)
    {
        if(!TextUtils.isEmpty(nomecomida.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                String sql = "INSERT INTO cardapio (nomecomida, ingredientes, valor) VALUES (?,?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1, nomecomida.getText().toString());
                stmt.bindString(2, ingredientes.getText().toString());
                stmt.bindDouble(3, Double.parseDouble(valor.getText().toString()));
                stmt.executeInsert();
                bancoDados.close();
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

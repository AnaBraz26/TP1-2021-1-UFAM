package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AMActivity extends AppCompatActivity {


    private SQLiteDatabase bancoDados;
    EditText numero, idpedido, idgarcom;
    public Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amactivity);

        numero = (EditText) findViewById(R.id.numero);
        idpedido = (EditText) findViewById(R.id.idpedido);
        idgarcom = (EditText) findViewById(R.id.idgarcom);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);
        carregarDados(id);
    }

    public void carregarDados(int id)
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM mesa WHERE id = " + id ,null);

            if(cursor.moveToNext()) {
                numero.setText((Integer.toString(cursor.getInt(1))));
                idpedido.setText((Integer.toString(cursor.getInt(2))));
                idgarcom.setText((Integer.toString(cursor.getInt(3))));
            }
            bancoDados.close();

        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void alterar(View view){
        int valueValor= Integer.parseInt(numero.getText().toString());
        int valueValor1= Integer.parseInt(idpedido.getText().toString());
        int valueValor2= Integer.parseInt(idgarcom.getText().toString());

        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            String sql = "UPDATE mesa SET numero = ?, idpedido = ?, idgarcom = ? WHERE id = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);

            stmt.bindLong(1, valueValor);
            stmt.bindLong(2, valueValor1);
            stmt.bindLong(3, valueValor2);
            stmt.bindLong(4, id);

            stmt.executeUpdateDelete();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }

        finish();
    }
}
package br.edu.icomp.tp2final;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class PedidoActivity extends AppCompatActivity {


    private SQLiteDatabase bancoDados;
    public ListView listViewPedido;
    public Button botao;
    public ArrayList<Integer> ids;
    public Integer id;
    public String comida,mesa, status, observação;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pedido);

        listViewPedido = (ListView)  findViewById(R.id.listViewPedido);

        listViewPedido.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                confirmaExcluir((int) id);
                return true;
            }
        });

        listViewPedido.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                abrirTelaAlterar((int) id);
            }
        });

        criarBancoDados();
        listarDados();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        listarDados();
    }

    public void criarBancoDados()
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS pedido (" +
                    "  id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ", idcomida INTEGER" +
                    ", mesa INTEGER " +
                    ", status VARCHAR"+
                    ", observação DOUBLE)");
            bancoDados.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void listarDados(){

        try{
            ids = new ArrayList<>();
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT id,idcomida,mesa,status,observação FROM pedido", null);
            ArrayList<String> linha = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>( this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linha);

            listViewPedido.setAdapter(meuAdapter);
            cursor.moveToFirst();
            while(cursor != null){
                linha.add(Integer.toString(cursor.getInt(0)));
                ids.add(cursor.getInt(0));
                cursor.moveToNext();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro(View view){
        Intent intent = new Intent(this, CPActivity.class);
        startActivity(intent);
    }

    public void confirmaExcluir(int id)
    {
        AlertDialog.Builder msgBox = new AlertDialog.Builder(PedidoActivity.this);
        AlertDialog.Builder msgBox1 = new AlertDialog.Builder(PedidoActivity.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você realmente deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    String sql = "DELETE FROM pedido WHERE id = ?";
                    SQLiteStatement stmt = bancoDados.compileStatement(sql);
                    stmt.bindLong(1, id);
                    stmt.executeUpdateDelete();
                    listarDados();
                    bancoDados.close();
                }catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.setNeutralButton("Ver registro", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                msgBox1.setTitle("Registro");
                msgBox1.setIcon(android.R.drawable.ic_menu_view);

                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    Cursor cursor = bancoDados.rawQuery("SELECT * FROM pedido WHERE id = " + id ,null);

                    if(cursor.moveToNext()) {
                        comida = Integer.toString(cursor.getInt(1));
                        mesa = Integer.toString(cursor.getInt(2));
                        status = cursor.getString(3);
                        observação = cursor.getString(4);

                    }
                    bancoDados.close();

                }catch (Exception e)
                {
                    e.printStackTrace();
                }

                msgBox1.setMessage("Número da comida: "+comida+ "\n\nMesa: " +mesa+"\n\nStatus: "+status+"\n\nObservações: "+observação) ;
                msgBox1.show();
            }
        });
        msgBox.show();
    }

    public void  abrirTelaAlterar(int id)
    {
        Intent intent = new Intent(this, APActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

}
package br.edu.icomp.tp2final;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class CardapioActivity extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    public ListView listViewCardapio;
    public Button botao;
    public ArrayList<Integer> ids;
    public Integer id;
    public String comida, ingredientes,valor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cardapio);

        listViewCardapio = (ListView)  findViewById(R.id.listViewCardapio);

        listViewCardapio.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                confirmaExcluir((int) id);
                return true;
            }
        });

        listViewCardapio.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                abrirTelaAlterar((int) id);
            }
        });

        criarBancoDados();
        listarDados();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        listarDados();
    }

    public void criarBancoDados()
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS cardapio (" +
                    "  id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ", nomecomida VARCHAR"+
                    ", ingredientes VARCHAR" +
                    ", valor DOUBLE)");
            bancoDados.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void listarDados(){

        try{
            ids = new ArrayList<>();
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT id, nomecomida, ingredientes, valor FROM cardapio", null);
            ArrayList<String> linha = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>( this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linha);

            listViewCardapio.setAdapter(meuAdapter);
            cursor.moveToFirst();
            while(cursor != null){
                linha.add(cursor.getString(1));
                ids.add(cursor.getInt(0));
                cursor.moveToNext();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro(View view){
        Intent intent = new Intent(this, CCActivity.class);
        startActivity(intent);
    }

    public void confirmaExcluir(int id)
    {
        AlertDialog.Builder msgBox = new AlertDialog.Builder(CardapioActivity.this);
        AlertDialog.Builder msgBox1 = new AlertDialog.Builder(CardapioActivity.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você realmente deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    String sql = "DELETE FROM cardapio WHERE id = ?";
                    SQLiteStatement stmt = bancoDados.compileStatement(sql);
                    stmt.bindLong(1, id);
                    stmt.executeUpdateDelete();
                    listarDados();
                    bancoDados.close();
                }catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.setNeutralButton("Ver registro", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                msgBox1.setTitle("Registro");
                msgBox1.setIcon(android.R.drawable.ic_menu_view);

                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    Cursor cursor = bancoDados.rawQuery("SELECT * FROM cardapio WHERE id = " + id ,null);

                    if(cursor.moveToNext()) {
                        comida = cursor.getString(1);
                        ingredientes = cursor.getString(2);
                        valor = Double.toString(cursor.getDouble(3));
                    }
                    bancoDados.close();

                }catch (Exception e)
                {
                    e.printStackTrace();
                }

                msgBox1.setMessage("Comida: "+comida+"\n\nIngredientes: "+ingredientes+"\n\nValor R$ "+valor) ;
                msgBox1.show();
            }
        });
        msgBox.show();
    }

    public void  abrirTelaAlterar(int id)
    {
        Intent intent = new Intent(this, ACActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

}
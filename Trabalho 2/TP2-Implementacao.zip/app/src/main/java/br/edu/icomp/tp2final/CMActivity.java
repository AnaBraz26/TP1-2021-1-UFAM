package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class CMActivity extends AppCompatActivity {

    EditText numero, idpedido, idgarcom;
    SQLiteDatabase bancoDados;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cmactivity);

        numero = (EditText) findViewById(R.id.numero);
        idpedido = (EditText) findViewById(R.id.idpedido);
        idgarcom = (EditText) findViewById(R.id.idgarcom);
    }

    public void cadastrar(View view)
    {
        if(!TextUtils.isEmpty(numero.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                String sql = "INSERT INTO mesa (numero,idpedido,idgarcom) VALUES (?,?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindLong(1, Long.parseLong(numero.getText().toString()));
                stmt.bindLong(2, Long.parseLong(idpedido.getText().toString()));
                stmt.bindLong(3, Long.parseLong(idgarcom.getText().toString()));

                stmt.executeInsert();
                bancoDados.close();
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

package br.edu.icomp.tp2final;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class MesaActivity extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    public ListView listViewMesa;
    public ArrayList<Integer> ids;
    public Integer id;
    public String mesa,pedido,garcom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mesa);

        listViewMesa = (ListView)  findViewById(R.id.listViewMesa);

        listViewMesa.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                confirmaExcluir((int) id);
                return true;
            }
        });

        listViewMesa.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                id = ids.get(position);
                abrirTelaAlterar((int) id);
            }
        });

        criarBancoDados();
        listarDados();
    }

    @Override
    protected void onResume()
    {
        super.onResume();
        listarDados();
    }

    public void criarBancoDados()
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS mesa (" +
                    "  id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ", numero INTEGER" +
                    ", idpedido INTEGER " +
                    ", idgarcom VARCHAR)");
            bancoDados.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void listarDados(){

        try{
            ids = new ArrayList<>();
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT id,numero,idpedido,idgarcom FROM mesa", null);
            ArrayList<String> linha = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>( this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linha);

            listViewMesa.setAdapter(meuAdapter);
            cursor.moveToFirst();
            while(cursor != null){
                linha.add(Integer.toString(cursor.getInt(1)));
                ids.add(cursor.getInt(0));
                cursor.moveToNext();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro(View view){
        Intent intent = new Intent(this, CMActivity.class);
        startActivity(intent);
    }

    public void confirmaExcluir(int id)
    {
        AlertDialog.Builder msgBox = new AlertDialog.Builder(MesaActivity.this);
        AlertDialog.Builder msgBox1 = new AlertDialog.Builder(MesaActivity.this);
        msgBox.setTitle("Excluir");
        msgBox.setIcon(android.R.drawable.ic_menu_delete);
        msgBox.setMessage("Você realmente deseja excluir esse registro?");
        msgBox.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    String sql = "DELETE FROM mesa WHERE id = ?";
                    SQLiteStatement stmt = bancoDados.compileStatement(sql);
                    stmt.bindLong(1, id);
                    stmt.executeUpdateDelete();
                    listarDados();
                    bancoDados.close();
                }catch(Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
        msgBox.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        msgBox.setNeutralButton("Ver registro", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                msgBox1.setTitle("Registro");
                msgBox1.setIcon(android.R.drawable.ic_menu_view);

                try{
                    bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                    Cursor cursor = bancoDados.rawQuery("SELECT * FROM mesa WHERE id = "+ id,null);

                    if(cursor.moveToNext()) {
                        mesa = Integer.toString(cursor.getInt(1));
                        pedido = Integer.toString(cursor.getInt(2));
                        garcom = Integer.toString(cursor.getInt(3));
                    }
                    bancoDados.close();
                }catch (Exception e)
                {
                    e.printStackTrace();
                }

                msgBox1.setMessage("Número da mesa: "+ mesa +"\n\nNúmero do pedido: "+ pedido +" \n\nNúmero do id do garçom: "+ garcom) ;
                msgBox1.show();
            }
        });
        msgBox.show();
    }

    public void  abrirTelaAlterar(int id)
    {
        Intent intent = new Intent(this, AMActivity.class);
        intent.putExtra("id", id);
        startActivity(intent);
    }

}
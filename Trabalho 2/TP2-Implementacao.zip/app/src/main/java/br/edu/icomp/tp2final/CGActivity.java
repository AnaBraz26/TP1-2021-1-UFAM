package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class CGActivity extends AppCompatActivity {

    EditText nome, salario;
    SQLiteDatabase bancoDados;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgactivity);

        nome = (EditText) findViewById(R.id.nome);
        salario = (EditText) findViewById(R.id.salario);
    }

    public void cadastrar(View view)
    {
        if(!TextUtils.isEmpty(nome.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                String sql = "INSERT INTO garcom (nome, salario) VALUES (?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1, nome.getText().toString());
                stmt.bindDouble(2, Double.parseDouble(salario.getText().toString()));
                stmt.executeInsert();
                bancoDados.close();
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}





package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AGActivity extends AppCompatActivity {

    private SQLiteDatabase bancoDados;
    public EditText nome, salario;
    public Integer id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agactivity);

        nome = (EditText) findViewById(R.id.nome);
        salario = (EditText) findViewById(R.id.salario);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", 0);
        carregarDados(id);
    }

    public void carregarDados(int id)
    {
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM garcom WHERE id = "+ id,null);

            if(cursor.moveToNext()) {
                nome.setText(cursor.getString(1));
                salario.setText((Double.toString(cursor.getDouble(2))));
            }
            bancoDados.close();
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    public void alterar(View view){
        String valueNome = nome.getText().toString();
        double valueSalario = Double.parseDouble(salario.getText().toString());
        try{
            bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
            String sql = "UPDATE garcom SET nome = ?, salario = ? WHERE id = ?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindString(1,valueNome);
            stmt.bindDouble(2, valueSalario);
            stmt.bindLong(3,id);
            stmt.executeUpdateDelete();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        finish();
    }
}
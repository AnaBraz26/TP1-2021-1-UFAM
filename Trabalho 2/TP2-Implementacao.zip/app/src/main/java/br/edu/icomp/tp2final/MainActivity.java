package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void entrarGarcom(View view)
    {
        Intent intent = new Intent(this, GarcomActivity.class);
        startActivity(intent);
    }

    public void entrarCardapio(View view)
    {
        Intent intent = new Intent(this, CardapioActivity.class);
        startActivity(intent);
    }

    public void entrarPedido(View view)
    {
        Intent intent = new Intent(this, PedidoActivity.class);
        startActivity(intent);
    }

    public void entrarMesa(View view)
    {
        Intent intent = new Intent(this, MesaActivity.class);
        startActivity(intent);
    }

}
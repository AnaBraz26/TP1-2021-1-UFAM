package br.edu.icomp.tp2final;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

public class CPActivity extends AppCompatActivity {

    EditText idcomida, mesa, status, observação;
    SQLiteDatabase bancoDados;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cpactivity);

        idcomida = (EditText) findViewById(R.id.idcomida);
        mesa = (EditText) findViewById(R.id.numero);
        status = (EditText) findViewById(R.id.status);
        observação = (EditText) findViewById(R.id.observação);
    }

    public void cadastrar(View view)
    {
        if(!TextUtils.isEmpty(idcomida.getText().toString())) {
            try {
                bancoDados = openOrCreateDatabase("TP2FINAL", MODE_PRIVATE, null);
                String sql = "INSERT INTO pedido (idcomida, mesa, status, observação) VALUES (?,?,?,?)";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindLong(1, Long.parseLong(idcomida.getText().toString()));
                stmt.bindLong(2, Long.parseLong(mesa.getText().toString()));
                stmt.bindString(3, status.getText().toString());
                stmt.bindString(4, observação.getText().toString());
                stmt.executeInsert();
                bancoDados.close();
                finish();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
